from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, delete
from app.modules.content.models import Film, CinemaHall, Session

class ContentRepository:
    def __init__(self, db: AsyncSession):
        self.db = db

    # Film CRUD
    async def create_film(self, film: Film) -> Film:
        self.db.add(film)
        await self.db.commit()
        await self.db.refresh(film)
        return film

    async def get_films(self, skip: int = 0, limit: int = 100):
        result = await self.db.execute(select(Film).offset(skip).limit(limit))
        return result.scalars().all()

    async def get_film(self, film_id: int) -> Film | None:
        result = await self.db.execute(select(Film).where(Film.id == film_id))
        return result.scalar_one_or_none()

    async def update_film(self, film_id: int, data: dict) -> Film | None:
        film = await self.get_film(film_id)
        if not film:
            return None
        for key, value in data.items():
            setattr(film, key, value)
        await self.db.commit()
        await self.db.refresh(film)
        return film

    async def delete_film(self, film_id: int) -> bool:
        result = await self.db.execute(delete(Film).where(Film.id == film_id))
        await self.db.commit()
        return result.rowcount > 0

    # Hall CRUD
    async def create_hall(self, hall: CinemaHall) -> CinemaHall:
        self.db.add(hall)
        await self.db.commit()
        await self.db.refresh(hall)
        await self.create_seats_for_hall(hall.id, hall.rows_count, hall.seats_per_row)
        return hall

    async def get_halls(self):
        result = await self.db.execute(select(CinemaHall))
        return result.scalars().all()

    async def get_hall(self, hall_id: int) -> CinemaHall | None:
        result = await self.db.execute(select(CinemaHall).where(CinemaHall.id == hall_id))
        return result.scalar_one_or_none()

    async def update_hall(self, hall_id: int, data: dict) -> CinemaHall | None:
        hall = await self.get_hall(hall_id)
        if not hall:
            return None
        for key, value in data.items():
            setattr(hall, key, value)
        await self.db.commit()
        await self.db.refresh(hall)
        return hall

    async def delete_hall(self, hall_id: int) -> bool:
        result = await self.db.execute(delete(CinemaHall).where(CinemaHall.id == hall_id))
        await self.db.commit()
        return result.rowcount > 0

    async def create_seats_for_hall(self, hall_id: int, rows: int, seats_per_row: int):
        from app.modules.booking.models import Seat
        seats = []
        for row in range(1, rows + 1):
            for seat_num in range(1, seats_per_row + 1):
                seats.append(Seat(hall_id=hall_id, row_num=row, seat_num=seat_num))
        self.db.add_all(seats)
        await self.db.commit()

    # Session CRUD
    async def create_session(self, session: Session) -> Session:
        self.db.add(session)
        await self.db.commit()
        await self.db.refresh(session)
        return session

    async def get_sessions(self):
        result = await self.db.execute(select(Session))
        return result.scalars().all()

    async def get_session(self, session_id: int) -> Session | None:
        result = await self.db.execute(select(Session).where(Session.id == session_id))
        return result.scalar_one_or_none()
