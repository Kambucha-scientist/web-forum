from sqlalchemy.ext.asyncio import AsyncSession
from app.modules.content.repository import ContentRepository
from app.modules.content.models import Film, CinemaHall, Session
from app.modules.content.schemas import FilmCreate, HallCreate, SessionCreate

class ContentService:
    def __init__(self, db: AsyncSession):
        self.repo = ContentRepository(db)

    async def create_film(self, data: FilmCreate) -> Film:
        film = Film(**data.dict())
        return await self.repo.create_film(film)

    async def get_films(self):
        return await self.repo.get_films()

    async def get_film(self, film_id: int):
        return await self.repo.get_film(film_id)

    async def update_film(self, film_id: int, data: dict):
        return await self.repo.update_film(film_id, data)

    async def delete_film(self, film_id: int):
        return await self.repo.delete_film(film_id)

    async def create_hall(self, data: HallCreate) -> CinemaHall:
        hall = CinemaHall(**data.dict())
        return await self.repo.create_hall(hall)

    async def get_halls(self):
        return await self.repo.get_halls()

    async def update_hall(self, hall_id: int, data: dict):
        return await self.repo.update_hall(hall_id, data)

    async def delete_hall(self, hall_id: int):
        return await self.repo.delete_hall(hall_id)

    async def create_session(self, data: SessionCreate) -> Session:
        session = Session(**data.dict())
        return await self.repo.create_session(session)

    async def get_sessions(self):
        return await self.repo.get_sessions()

    async def get_session(self, session_id: int):
        return await self.repo.get_session(session_id)
