from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, Float
from app.core.database import Base
from datetime import datetime

class Film(Base):
    __tablename__ = "films"
    id = Column(Integer, primary_key=True, index=True)
    title = Column(String, nullable=False)
    genre = Column(String, nullable=False)
    age_restriction = Column(Integer, nullable=False)
    duration_min = Column(Integer, nullable=False)
    description = Column(String, nullable=True)
    poster_url = Column(String, nullable=True)

class CinemaHall(Base):
    __tablename__ = "cinema_halls"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    rows_count = Column(Integer, nullable=False)
    seats_per_row = Column(Integer, nullable=False)

class Session(Base):
    __tablename__ = "sessions"
    id = Column(Integer, primary_key=True, index=True)
    film_id = Column(Integer, ForeignKey("films.id"), nullable=False)
    hall_id = Column(Integer, ForeignKey("cinema_halls.id"), nullable=False)
    start_datetime = Column(DateTime, nullable=False)
    base_price = Column(Float, nullable=False)
