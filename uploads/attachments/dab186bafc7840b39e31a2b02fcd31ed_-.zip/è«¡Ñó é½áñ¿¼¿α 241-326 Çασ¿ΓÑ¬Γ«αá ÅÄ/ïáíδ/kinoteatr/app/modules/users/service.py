from sqlalchemy.ext.asyncio import AsyncSession
from app.modules.users.repository import UserRepository
from app.modules.users.models import User, UserRoleEnum
from app.modules.users.schemas import UserCreate
from app.core.security import get_password_hash, verify_password

class UserService:
    def __init__(self, db: AsyncSession):
        self.repo = UserRepository(db)

    async def register(self, user_data: UserCreate) -> User:
        existing = await self.repo.get_by_email(user_data.email)
        if existing:
            raise ValueError("User with this email already exists")
        hashed = get_password_hash(user_data.password)
        user = User(
            email=user_data.email,
            phone=user_data.phone,
            full_name=user_data.full_name,
            hashed_password=hashed,
            role=UserRoleEnum.viewer
        )
        return await self.repo.create(user)

    async def authenticate(self, email: str, password: str) -> User | None:
        user = await self.repo.get_by_email(email)
        if not user or not verify_password(password, user.hashed_password):
            return None
        return user

    async def get_user_by_id(self, user_id: int) -> User | None:
        return await self.repo.get_by_id(user_id)
