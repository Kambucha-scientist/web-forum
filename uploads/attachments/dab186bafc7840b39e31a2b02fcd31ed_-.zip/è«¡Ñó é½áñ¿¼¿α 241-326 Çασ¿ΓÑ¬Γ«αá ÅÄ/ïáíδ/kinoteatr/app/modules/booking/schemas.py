from pydantic import BaseModel
from datetime import datetime


class SeatOut(BaseModel):
    id: int
    hall_id: int
    row_num: int
    seat_num: int

class BookingCreate(BaseModel):
    session_id: int
    seat_id: int

class BookingOut(BaseModel):
    id: int
    user_id: int
    session_id: int
    seat_id: int
    booking_time: datetime
    expires_at: datetime
    status: str

class TicketCreate(BaseModel):
    session_id: int
    seat_id: int

class TicketOut(BaseModel):
    id: int
    user_id: int
    session_id: int
    seat_id: int
    price: float
    purchase_time: datetime
    status: str

class OccupiedSeatsResponse(BaseModel):
    occupied_seat_ids: list[int]

class SeatsStatusResponse(BaseModel):
    booked_seat_ids: list[int]
    sold_seat_ids: list[int]
