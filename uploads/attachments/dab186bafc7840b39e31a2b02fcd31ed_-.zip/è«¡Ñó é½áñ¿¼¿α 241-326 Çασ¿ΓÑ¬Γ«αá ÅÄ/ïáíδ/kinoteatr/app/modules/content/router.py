from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.database import get_db
from app.core.dependencies import get_current_admin
from app.modules.content.service import ContentService
from app.modules.content.schemas import FilmCreate, FilmOut, HallCreate, HallOut, SessionCreate, SessionOut

router = APIRouter(prefix="/content", tags=["content"])

@router.get("/films", response_model=list[FilmOut])
async def list_films(db: AsyncSession = Depends(get_db)):
    service = ContentService(db)
    films = await service.get_films()
    return films

@router.post("/films", response_model=FilmOut, dependencies=[Depends(get_current_admin)])
async def create_film(data: FilmCreate, db: AsyncSession = Depends(get_db)):
    service = ContentService(db)
    film = await service.create_film(data)
    return film

@router.get("/films/{film_id}", response_model=FilmOut)
async def get_film(film_id: int, db: AsyncSession = Depends(get_db)):
    service = ContentService(db)
    film = await service.get_film(film_id)
    if not film:
        raise HTTPException(status_code=404)
    return film

@router.put("/films/{film_id}", response_model=FilmOut, dependencies=[Depends(get_current_admin)])
async def update_film(film_id: int, data: FilmCreate, db: AsyncSession = Depends(get_db)):
    service = ContentService(db)
    film = await service.update_film(film_id, data.dict())
    if not film:
        raise HTTPException(status_code=404)
    return film

@router.delete("/films/{film_id}", dependencies=[Depends(get_current_admin)])
async def delete_film(film_id: int, db: AsyncSession = Depends(get_db)):
    service = ContentService(db)
    deleted = await service.delete_film(film_id)
    if not deleted:
        raise HTTPException(status_code=404)
    return {"ok": True}

@router.get("/halls", response_model=list[HallOut])
async def list_halls(db: AsyncSession = Depends(get_db)):
    service = ContentService(db)
    return await service.get_halls()

@router.post("/halls", response_model=HallOut, dependencies=[Depends(get_current_admin)])
async def create_hall(data: HallCreate, db: AsyncSession = Depends(get_db)):
    service = ContentService(db)
    return await service.create_hall(data)

@router.get("/sessions", response_model=list[SessionOut])
async def list_sessions(db: AsyncSession = Depends(get_db)):
    service = ContentService(db)
    return await service.get_sessions()

@router.post("/sessions", response_model=SessionOut, dependencies=[Depends(get_current_admin)])
async def create_session(data: SessionCreate, db: AsyncSession = Depends(get_db)):
    service = ContentService(db)
    return await service.create_session(data)
