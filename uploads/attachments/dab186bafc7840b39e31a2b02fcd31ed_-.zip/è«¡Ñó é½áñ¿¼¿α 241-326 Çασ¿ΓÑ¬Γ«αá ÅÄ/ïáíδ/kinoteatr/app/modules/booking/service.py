from datetime import datetime, timedelta
from sqlalchemy.ext.asyncio import AsyncSession
from app.modules.booking.repository import BookingRepository
from app.modules.booking.models import Booking, Ticket, BookingStatusEnum, TicketStatusEnum
from app.modules.content.repository import ContentRepository
from app.utils.exceptions import BusinessError
import logging
logger = logging.getLogger(__name__)


class BookingService:
    def __init__(self, db: AsyncSession):
        self.db = db
        self.repo = BookingRepository(db)
        self.content_repo = ContentRepository(db)

    async def reserve_seat(self, user_id: int, session_id: int, seat_id: int) -> Booking:
        logger.info(f"Попытка бронирования seat_id={seat_id} для user_id={user_id}")
        try:
            # Блокируем строку места
            seat = await self.repo.lock_seat_for_update(seat_id)
            if not seat:
                raise BusinessError("Место не найдено")

            # Проверяем, нет ли уже купленного билета
            ticket = await self.repo.get_active_ticket_for_seat(session_id, seat_id)
            if ticket:
                raise BusinessError("Это место уже куплено")

            # Проверяем, нет ли активной брони
            booking = await self.repo.get_active_booking_for_seat(session_id, seat_id)
            if booking:
                if booking.user_id == user_id:
                    raise BusinessError("Вы уже забронировали это место")
                else:
                    raise BusinessError("Это место уже забронировано другим пользователем")

            # Создаём бронь на 15 минут
            expires = datetime.utcnow() + timedelta(minutes=15)
            new_booking = Booking(
                user_id=user_id,
                session_id=session_id,
                seat_id=seat_id,
                expires_at=expires,
                status=BookingStatusEnum.active
            )
            new_booking = await self.repo.create_booking(new_booking)
            await self.db.commit()
            await self.db.refresh(new_booking)
            return new_booking
        except Exception as e:
            await self.db.rollback()
            logger.error(f"Ошибка бронирования: {e}")
            raise e

    async def buy_ticket(self, user_id: int, session_id: int, seat_id: int, price: float) -> Ticket:
        try:
            # Блокируем строку места
            seat = await self.repo.lock_seat_for_update(seat_id)
            if not seat:
                raise BusinessError("Место не найдено")

            # Проверяем, нет ли уже купленного билета
            ticket = await self.repo.get_active_ticket_for_seat(session_id, seat_id)
            if ticket:
                raise BusinessError("Билет на это место уже продан")

            # Проверяем бронь
            booking = await self.repo.get_active_booking_for_seat(session_id, seat_id)
            if booking and booking.user_id != user_id:
                raise BusinessError("Это место забронировано другим пользователем. Дождитесь снятия брони.")

            # Создаём билет
            new_ticket = Ticket(
                user_id=user_id,
                session_id=session_id,
                seat_id=seat_id,
                price=price,
                status=TicketStatusEnum.active
            )
            new_ticket = await self.repo.create_ticket(new_ticket)

            # Если была бронь текущего пользователя, удаляем её
            if booking and booking.user_id == user_id:
                await self.repo.delete_booking_by_id(booking.id)

            await self.db.commit()
            await self.db.refresh(new_ticket)
            return new_ticket
        except Exception as e:
            await self.db.rollback()
            raise e
        
    async def get_user_tickets(self, user_id: int):
        return await self.repo.get_user_tickets(user_id)
    
    async def get_occupied_seat_ids(self, session_id: int) -> list[int]:
        return await self.repo.get_occupied_seat_ids(session_id)

    async def get_seats_status(self, session_id: int) -> tuple[list[int], list[int]]:
        return await self.repo.get_seats_status(session_id)
   