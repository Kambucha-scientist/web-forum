from sqlalchemy import Column, Integer, DateTime, ForeignKey, String, Float, Enum
from app.core.database import Base
from datetime import datetime
import enum

class BookingStatusEnum(enum.Enum):
    active = "active"
    cancelled = "cancelled"

class TicketStatusEnum(enum.Enum):
    active = "active"
    refunded = "refunded"

class Seat(Base):
    __tablename__ = "seats"
    id = Column(Integer, primary_key=True, index=True)
    hall_id = Column(Integer, ForeignKey("cinema_halls.id"), nullable=False)
    row_num = Column(Integer, nullable=False)
    seat_num = Column(Integer, nullable=False)

class Booking(Base):
    __tablename__ = "bookings"
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    session_id = Column(Integer, ForeignKey("sessions.id"), nullable=False)
    seat_id = Column(Integer, ForeignKey("seats.id"), nullable=False)
    booking_time = Column(DateTime, default=datetime.utcnow)
    expires_at = Column(DateTime, nullable=False)
    status = Column(Enum(BookingStatusEnum), default=BookingStatusEnum.active)

class Ticket(Base):
    __tablename__ = "tickets"
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    session_id = Column(Integer, ForeignKey("sessions.id"), nullable=False)
    seat_id = Column(Integer, ForeignKey("seats.id"), nullable=False)
    price = Column(Float, nullable=False)
    purchase_time = Column(DateTime, default=datetime.utcnow)
    status = Column(Enum(TicketStatusEnum), default=TicketStatusEnum.active)
    qr_code = Column(String, nullable=True)
