from pydantic import BaseModel
from datetime import datetime
from typing import Optional

class FilmBase(BaseModel):
    title: str
    genre: str
    age_restriction: int
    duration_min: int
    description: Optional[str] = None
    poster_url: Optional[str] = None

class FilmCreate(FilmBase):
    pass

class FilmOut(FilmBase):
    id: int

class HallBase(BaseModel):
    name: str
    rows_count: int
    seats_per_row: int

class HallCreate(HallBase):
    pass

class HallOut(HallBase):
    id: int

class SessionBase(BaseModel):
    film_id: int
    hall_id: int
    start_datetime: datetime
    base_price: float

class SessionCreate(SessionBase):
    pass

class SessionOut(SessionBase):
    id: int
