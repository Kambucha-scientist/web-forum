from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.modules.booking.models import Seat, Booking, Ticket, BookingStatusEnum, TicketStatusEnum
from datetime import datetime

class BookingRepository:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def create_booking(self, booking: Booking) -> Booking:
        self.db.add(booking)
        return booking  # коммит в сервисе

    async def create_ticket(self, ticket: Ticket) -> Ticket:
        self.db.add(ticket)
        return ticket

    async def get_active_booking_for_seat(self, session_id: int, seat_id: int) -> Booking | None:
        stmt = select(Booking).where(
            Booking.session_id == session_id,
            Booking.seat_id == seat_id,
            Booking.status == BookingStatusEnum.active,
            Booking.expires_at > datetime.utcnow()
        )
        result = await self.db.execute(stmt)
        return result.scalar_one_or_none()

    async def get_active_ticket_for_seat(self, session_id: int, seat_id: int) -> Ticket | None:
        stmt = select(Ticket).where(
            Ticket.session_id == session_id,
            Ticket.seat_id == seat_id,
            Ticket.status == TicketStatusEnum.active
        )
        result = await self.db.execute(stmt)
        return result.scalar_one_or_none()

    async def lock_seat_for_update(self, seat_id: int):
        stmt = select(Seat).where(Seat.id == seat_id).with_for_update()
        result = await self.db.execute(stmt)
        return result.scalar_one_or_none()

    async def delete_booking_by_id(self, booking_id: int):
        booking = await self.db.get(Booking, booking_id)
        if booking:
            await self.db.delete(booking)
    
    async def get_user_tickets(self, user_id: int):
        result = await self.db.execute(
            select(Ticket).where(Ticket.user_id == user_id)
        )
        return result.scalars().all()

    async def get_seats_status(self, session_id: int) -> tuple[list[int], list[int]]:
        # Забронированные
        booked_stmt = select(Booking.seat_id).where(
            Booking.session_id == session_id,
            Booking.status == BookingStatusEnum.active,
            Booking.expires_at > datetime.utcnow()
        )
        booked = [row[0] for row in (await self.db.execute(booked_stmt)).fetchall()]

        # Купленные
        sold_stmt = select(Ticket.seat_id).where(
            Ticket.session_id == session_id,
            Ticket.status == TicketStatusEnum.active
        )
        sold = [row[0] for row in (await self.db.execute(sold_stmt)).fetchall()]

        return booked, sold