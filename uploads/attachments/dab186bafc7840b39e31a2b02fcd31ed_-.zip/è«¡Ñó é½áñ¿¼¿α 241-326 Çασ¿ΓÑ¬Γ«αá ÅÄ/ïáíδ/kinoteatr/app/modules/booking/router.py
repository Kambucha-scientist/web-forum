from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.database import get_db
from app.core.dependencies import get_current_user
from app.modules.booking.service import BookingService
from app.modules.booking.schemas import BookingCreate, BookingOut, TicketCreate, TicketOut, SeatsStatusResponse
from app.modules.users.models import User
from app.utils.exceptions import BusinessError

router = APIRouter(prefix="/booking", tags=["booking"])

@router.post("/reserve", response_model=BookingOut)
async def reserve_seat(
    data: BookingCreate,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    service = BookingService(db)
    try:
        booking = await service.reserve_seat(current_user.id, data.session_id, data.seat_id)
        return booking
    except BusinessError as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.post("/buy", response_model=TicketOut)
async def buy_ticket(
    data: TicketCreate,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    service = BookingService(db)
    session_repo = service.content_repo
    session = await session_repo.get_session(data.session_id)
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    try:
        ticket = await service.buy_ticket(current_user.id, data.session_id, data.seat_id, session.base_price)
        return ticket
    except BusinessError as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.get("/my-tickets", response_model=list[TicketOut])
async def my_tickets(current_user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    service = BookingService(db)
    tickets = await service.get_user_tickets(current_user.id)
    return tickets

@router.get("/session/{session_id}/seats-status", response_model=SeatsStatusResponse)
async def get_seats_status(session_id: int, db: AsyncSession = Depends(get_db)):
    service = BookingService(db)
    booked, sold = await service.get_seats_status(session_id)
    return SeatsStatusResponse(booked_seat_ids=booked, sold_seat_ids=sold)