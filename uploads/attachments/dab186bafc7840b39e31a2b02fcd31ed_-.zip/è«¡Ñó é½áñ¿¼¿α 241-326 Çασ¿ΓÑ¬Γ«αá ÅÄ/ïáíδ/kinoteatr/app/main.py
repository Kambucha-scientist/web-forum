from fastapi import FastAPI
from app.core.database import engine, Base
from app.modules.users.router import router as users_router
from app.modules.content.router import router as content_router
from app.modules.booking.router import router as booking_router
from fastapi.middleware.cors import CORSMiddleware
from app.core.logging import setup_logging
setup_logging()

app = FastAPI(title="Cinema Prototype", version="1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.on_event("startup")
async def init_db():
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

app.include_router(users_router)      # /auth/*
app.include_router(content_router)    # /content/*
app.include_router(booking_router)    # /booking/*

@app.get("/")
async def root():
    return {"message": "Cinema API is running"}