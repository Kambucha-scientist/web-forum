const API = 'http://localhost:8000';
let ALL_SESSIONS = [];
let currentSession = null;
let selectedSeatId = null;
let HALLS_MAP = new Map();

const getToken = () => localStorage.getItem('cinema_token');
const setToken = (t) => localStorage.setItem('cinema_token', t);
const clearToken = () => localStorage.removeItem('cinema_token');

async function apiFetch(path, options = {}) {
    const headers = { 'Content-Type': 'application/json', ...(options.headers || {}) };
    const token = getToken();
    if (token) headers['Authorization'] = `Bearer ${token}`;

    const res = await fetch(`${API}${path}`, { ...options, headers });
    if (!res.ok) {
        const err = await res.json().catch(() => ({ detail: 'Ошибка сервера' }));
        throw new Error(err.detail || 'Запрос не выполнен');
    }
    return res.status === 204 ? null : res.json();
}

async function loadHalls() {
    if (HALLS_MAP.size > 0) return; // Кэшируем после первой загрузки
    try {
        const halls = await apiFetch('/content/halls');
        halls.forEach(h => HALLS_MAP.set(h.id, h.name));
    } catch (err) { console.error('Halls load error:', err); }
}

window.showView = (id) => {
    document.querySelectorAll('section').forEach(el => el.style.display = 'none');
    document.getElementById(id).style.display = 'block';
};
window.openModal = (id) => document.getElementById(id).style.display = 'flex';
window.closeModal = (id) => document.getElementById(id).style.display = 'none';

window.checkAuth = () => {
    const logged = !!getToken();
    document.getElementById('auth-nav').style.display = logged ? 'none' : 'flex';
    document.getElementById('user-nav').style.display = logged ? 'flex' : 'none';
    showView('films-view');
    loadFilms();
};
window.logout = () => { clearToken(); checkAuth(); };

document.getElementById('login-form').onsubmit = async (e) => {
    e.preventDefault();
    try {
        const data = await apiFetch('/auth/login', {
            method: 'POST',
            body: JSON.stringify({
                email: document.getElementById('login-email').value,
                password: document.getElementById('login-pass').value
            })
        });
        setToken(data.access_token);
        closeModal('login-modal');
        checkAuth();
    } catch (err) { alert(err.message); }
};

document.getElementById('reg-form').onsubmit = async (e) => {
    e.preventDefault();
    try {
        await apiFetch('/auth/register', {
            method: 'POST',
            body: JSON.stringify({
                email: document.getElementById('reg-email').value,
                password: document.getElementById('reg-pass').value,
                full_name: document.getElementById('reg-name').value,
                phone: document.getElementById('reg-phone').value
            })
        });
        alert('Регистрация успешна! Войдите.');
        closeModal('reg-modal');
    } catch (err) { alert(err.message); }
};

async function loadFilms() {
    try {
        const films = await apiFetch('/content/films');
        const grid = document.getElementById('films-grid');
        grid.innerHTML = '';
        films.forEach(f => {
            const card = document.createElement('div');
            card.className = 'film-card';
            const img = f.poster_url || 'https://via.placeholder.com/180x270?text=Нет+постера';
            card.innerHTML = `
                <img src="${img}" alt="${f.title}" onerror="this.src='https://via.placeholder.com/180x270?text=Ошибка'">
                <h3>${f.title}</h3>
                <p>${f.genre} • ${f.age_restriction}+ • ${f.duration_min} мин</p>
            `;
            card.onclick = () => loadSessions(f.id, f.title);
            grid.appendChild(card);
        });
    } catch (err) {
        document.getElementById('films-grid').innerHTML = `<p>Не удалось загрузить афишу: ${err.message}</p>`;
    }
}

async function loadSessions(filmId, title) {
    if (!getToken()) { openModal('login-modal'); return; }
    try {
        await loadHalls(); // Подгружаем имена залов один раз
        ALL_SESSIONS = await apiFetch('/content/sessions');
        const filtered = ALL_SESSIONS.filter(s => s.film_id === filmId);
        
        const container = document.getElementById('sessions-list');
        container.innerHTML = '';
        if (!filtered.length) container.innerHTML = '<p>Сеансов нет</p>';
        
        filtered.forEach(s => {
            const btn = document.createElement('button');
            btn.className = 'session-btn';
            const dt = s.start_datetime ? new Date(s.start_datetime).toLocaleString('ru-RU') : 'Время TBD';
            const hallName = HALLS_MAP.get(s.hall_id) || `Зал ${s.hall_id}`; // ✅ Имя вместо ID
            btn.textContent = `📅 ${dt} | ${hallName} | ${s.base_price}₽`;
            btn.onclick = () => openBooking(s);
            container.appendChild(btn);
        });
        document.getElementById('sessions-title').textContent = `Сеансы: ${title}`;
        showView('sessions-view');
    } catch (err) { alert(err.message); }
}

function openBooking(session) {
    currentSession = session;
    selectedSeatId = null;
    const hallName = HALLS_MAP.get(session.hall_id) || `Зал ${session.hall_id}`; // ✅ Имя вместо ID
    document.getElementById('booking-title').textContent = `Места: ${hallName}`;
    renderSeats(session.hall_id);
    showView('booking-view');
}

async function renderSeats(hallId) {
    const grid = document.getElementById('seats-grid');
    grid.innerHTML = '';
    
    try {
        // Получаем разделённые статусы
        const { booked_seat_ids, sold_seat_ids } = await apiFetch(`/booking/session/${currentSession.id}/seats-status`);
        const bookedSet = new Set(booked_seat_ids);
        const soldSet = new Set(sold_seat_ids);

        const halls = await apiFetch('/content/halls');
        const hall = halls.find(h => h.id === hallId);
        if (!hall) throw new Error('Схема зала не найдена');

        for (let r = 1; r <= hall.rows_count; r++) {
            const rowLabel = document.createElement('div');
            rowLabel.className = 'row-label';
            rowLabel.textContent = `Ряд ${r}`;
            grid.appendChild(rowLabel);

            const rowDiv = document.createElement('div');
            rowDiv.style.display = 'flex';
            rowDiv.style.justifyContent = 'center';
            rowDiv.style.gap = '6px';

            for (let c = 1; c <= hall.seats_per_row; c++) {
                const seatId = (r - 1) * hall.seats_per_row + c;
                const seat = document.createElement('div');
                seat.className = 'seat';
                seat.textContent = c;
                seat.dataset.id = seatId;
                
                // Применяем статусы
                if (soldSet.has(seatId)) {
                    seat.classList.add('sold');
                    seat.onclick = null; // Куплено → клик заблокирован
                } else if (bookedSet.has(seatId)) {
                    seat.classList.add('booked');
                    seat.onclick = () => selectSeat(seatId, seat); // Забронировано → клик разрешён
                } else {
                    seat.onclick = () => selectSeat(seatId, seat); // Свободно → клик разрешён
                }
                rowDiv.appendChild(seat);
            }
            grid.appendChild(rowDiv);
        }
    } catch (err) {
        grid.innerHTML = `<p style="color:#e53935">Ошибка загрузки мест: ${err.message}</p>`;
    }
}

function selectSeat(id, el) {
    if (el.classList.contains('occupied')) return;
    document.querySelectorAll('.seat.selected').forEach(s => s.classList.remove('selected'));
    selectedSeatId = id;
    el.classList.add('selected');
}

async function doBooking(action) {
    if (!selectedSeatId) return alert('Выберите место');
    const endpoint = action === 'reserve' ? '/booking/reserve' : '/booking/buy';
    try {
        await apiFetch(endpoint, {
            method: 'POST',
            body: JSON.stringify({ session_id: currentSession.id, seat_id: selectedSeatId })
        });
        alert(action === 'reserve' ? 'Забронировано на 15 мин!' : 'Билет куплен!');
        renderSeats(currentSession.hall_id); // Мгновенно обновляем цвета
    } catch (err) {
        // Бэкенд сам проверит, чья это бронь, и вернёт понятную ошибку
        alert(err.message); 
    }
}

document.getElementById('reserve-btn').onclick = () => doBooking('reserve');
document.getElementById('buy-btn').onclick = () => doBooking('buy');

window.loadTickets = async () => {
    try {
        const [tickets, sessions, halls, films] = await Promise.all([
            apiFetch('/booking/my-tickets'),
            apiFetch('/content/sessions'),
            apiFetch('/content/halls'),
            apiFetch('/content/films')
        ]);

        const sessionMap = new Map(sessions.map(s => [s.id, s]));
        const hallMap = new Map(halls.map(h => [h.id, h]));
        const filmMap = new Map(films.map(f => [f.id, f]));

        const container = document.getElementById('tickets-list');
        container.innerHTML = '';
        if (!tickets.length) { container.innerHTML = '<p>Билетов нет</p>'; return; }

        tickets.forEach(t => {
            const session = sessionMap.get(t.session_id);
            if (!session) return;

            const hall = hallMap.get(session.hall_id) || { name: 'Зал TBD', seats_per_row: 6 };
            const film = filmMap.get(session.film_id) || { title: 'Фильм TBD' };

            const date = session.start_datetime
                ? new Date(session.start_datetime).toLocaleString('ru-RU', { day: 'numeric', month: 'long', hour: '2-digit', minute: '2-digit' })
                : 'Время TBD';

            const row = Math.floor((t.seat_id - 1) / hall.seats_per_row) + 1;
            const seatInRow = ((t.seat_id - 1) % hall.seats_per_row) + 1;

            const div = document.createElement('div');
            div.style.border = '1px solid #000';
            div.style.padding = '10px';
            div.style.margin = '8px 0';
            div.style.fontSize = '14px';
            div.style.whiteSpace = 'nowrap';
            div.style.overflow = 'hidden';
            div.style.textOverflow = 'ellipsis';
            // Однострочный формат
            div.textContent = `🎬 ${film.title} | 📅 ${date} | 🏛️ ${hall.name} | 💺 Ряд ${row}, Место ${seatInRow}`;
            container.appendChild(div);
        });
        showView('tickets-view');
    } catch (err) { alert(err.message); }
};

document.addEventListener('DOMContentLoaded', checkAuth);