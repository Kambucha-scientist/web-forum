class BusinessError(Exception):
    pass
