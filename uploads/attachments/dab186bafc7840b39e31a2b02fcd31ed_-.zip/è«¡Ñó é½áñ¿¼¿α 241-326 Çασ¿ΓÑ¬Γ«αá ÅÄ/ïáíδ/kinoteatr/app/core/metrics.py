import time
import logging
from fastapi import Request, Response
from app.main import app

logger = logging.getLogger("metrics")

@app.middleware("http")
async def performance_metrics(request: Request, call_next):
    start = time.perf_counter()
    response = await call_next(request)
    duration = time.perf_counter() - start
    
    logger.info(
        f"{request.method} {request.url.path} | "
        f"status={response.status_code} | "
        f"time={duration:.3f}s | "
        f"ip={request.client.host}"
    )
    return response