from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy.ext.asyncio import AsyncSession
from jose import JWTError
import logging

from app.core.database import get_db
from app.core.security import decode_token
from app.modules.users.repository import UserRepository
from app.modules.users.schemas import UserRole

security = HTTPBearer()
logger = logging.getLogger(__name__)

async def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(security),
    db: AsyncSession = Depends(get_db)
):
    token = credentials.credentials
    try:
        payload = decode_token(token)
        user_id_str: str = payload.get("sub")
        if user_id_str is None:
            raise HTTPException(status_code=401, detail="Invalid token")

        # Преобразуем строку из JWT в целое число
        try:
            user_id = int(user_id_str)
        except ValueError:
            logger.error(f"User ID in token is not a valid integer: {user_id_str}")
            raise HTTPException(status_code=401, detail="Invalid token format")

    except JWTError as e:
        logger.error(f"JWT Decode Error: {e}")
        raise HTTPException(status_code=401, detail="Invalid token")

    user_repo = UserRepository(db)
    user = await user_repo.get_by_id(user_id)
    if not user:
        raise HTTPException(status_code=401, detail="User not found")
    return user

async def get_current_admin(current_user = Depends(get_current_user)):
    if current_user.role.value != UserRole.ADMIN.value:
        raise HTTPException(status_code=403, detail="Admin rights required")
    return current_user

async def get_current_cashier_or_admin(current_user = Depends(get_current_user)):
    if current_user.role not in [UserRole.ADMIN.value, UserRole.CASHIER.value]:
        raise HTTPException(status_code=403, detail="Cashier or admin rights required")
    return current_user
