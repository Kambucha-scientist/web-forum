async def test_create_film(client):
    res = await client.post("/content/films", json={
        "title": "Test Film",
        "genre": "Action",
        "age_restriction": 16,
        "duration_min": 120,
        "description": "Test desc",
        "poster_url": "https://example.com/poster.jpg"
    })
    assert res.status_code == 200
    data = res.json()
    assert data["title"] == "Test Film"

async def test_get_films(client):
    await client.post("/content/films", json={
        "title": "F1", "genre": "Drama", "age_restriction": 12, "duration_min": 90
    })
    res = await client.get("/content/films")
    assert res.status_code == 200
    assert isinstance(res.json(), list)

async def test_create_hall_and_session(client):
    hall_res = await client.post("/content/halls", json={
        "name": "Test Hall", "rows_count": 5, "seats_per_row": 6
    })
    assert hall_res.status_code == 200
    hall_id = hall_res.json()["id"]

    film_res = await client.post("/content/films", json={
        "title": "Movie", "genre": "Sci-Fi", "age_restriction": 16, "duration_min": 120
    })
    film_id = film_res.json()["id"]

    session_res = await client.post("/content/sessions", json={
        "film_id": film_id,
        "hall_id": hall_id,
        "start_datetime": "2025-12-31T18:00:00",
        "base_price": 350.0
    })
    assert session_res.status_code == 200