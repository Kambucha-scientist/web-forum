async def _setup_booking_test(client):
    """Вспомогательная функция: создаёт зал, фильм, сеанс"""
    hall = await client.post("/content/halls", json={
        "name": "Hall", "rows_count": 4, "seats_per_row": 4
    })
    film = await client.post("/content/films", json={
        "title": "M", "genre": "G", "age_restriction": 12, "duration_min": 100
    })
    session = await client.post("/content/sessions", json={
        "film_id": film.json()["id"],
        "hall_id": hall.json()["id"],
        "start_datetime": "2025-12-31T20:00:00",
        "base_price": 300.0
    })
    return session.json()["id"], 1

async def test_reserve_and_buy_flow(client):
    session_id, seat_id = await _setup_booking_test(client)
    
    reserve = await client.post("/booking/reserve", json={
        "session_id": session_id, "seat_id": seat_id
    })
    assert reserve.status_code == 200
    
    buy = await client.post("/booking/buy", json={
        "session_id": session_id, "seat_id": seat_id
    })
    assert buy.status_code == 200
    assert buy.json()["price"] == 300.0

async def test_get_my_tickets(client):
    session_id, seat_id = await _setup_booking_test(client)
    await client.post("/booking/buy", json={
        "session_id": session_id, "seat_id": seat_id
    })
    
    res = await client.get("/booking/my-tickets")
    assert res.status_code == 200
    tickets = res.json()
    assert len(tickets) >= 1  # ✅ Было: == 1
    # Дополнительно: убедимся, что среди билетов есть наш
    assert any(t["seat_id"] == seat_id for t in tickets)

async def test_double_booking_blocked(client):
    session_id, seat_id = await _setup_booking_test(client)
    
    r1 = await client.post("/booking/reserve", json={
        "session_id": session_id, "seat_id": seat_id
    })
    assert r1.status_code == 200
    
    r2 = await client.post("/booking/reserve", json={
        "session_id": session_id, "seat_id": seat_id
    })
    assert r2.status_code == 400
    detail = r2.json()["detail"]
    assert "Вы уже забронировали это место" in detail