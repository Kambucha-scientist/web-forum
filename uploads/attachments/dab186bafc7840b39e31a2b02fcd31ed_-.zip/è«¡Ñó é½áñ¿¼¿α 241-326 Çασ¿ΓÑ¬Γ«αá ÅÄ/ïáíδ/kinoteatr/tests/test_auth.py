import pytest

async def test_register_success(client):
    res = await client.post("/auth/register", json={
        "email": "new@test.com",
        "password": "SecurePass123!",
        "full_name": "New User"
    })
    assert res.status_code == 200
    data = res.json()
    assert data["email"] == "new@test.com"
    assert data["role"] == "viewer"

async def test_register_duplicate_email(client):
    await client.post("/auth/register", json={
        "email": "dup@test.com", "password": "pass", "full_name": "Dup"
    })
    res = await client.post("/auth/register", json={
        "email": "dup@test.com", "password": "pass", "full_name": "Dup2"
    })
    assert res.status_code == 400
    assert "already exists" in res.json()["detail"]

async def test_login_success(client):
    await client.post("/auth/register", json={
        "email": "login@test.com", "password": "pass123", "full_name": "User"
    })
    res = await client.post("/auth/login", json={
        "email": "login@test.com", "password": "pass123"
    })
    assert res.status_code == 200
    assert "access_token" in res.json()

async def test_login_invalid_credentials(client):
    res = await client.post("/auth/login", json={
        "email": "wrong@test.com", "password": "wrong"
    })
    assert res.status_code == 401